import smtplib, argparse

from platform import system as SYS
from os import linesep, system
from sys import exit
from datetime import datetime
from time import sleep
from random import randint
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


def startsend(host, port, login, password, subject, att, emails, plain=""):
    """method to arrange and send based on inputs"""
    if "win" in SYS().lower():
        system("cls")
    else:
        system("clear")
    
    count = 0
    try:
        print("Signing in to Mailbox ...")
        s = smtplib.SMTP(host=host, port=port)
        s.starttls()
        try:
            if s.login(login, password):
                print("Successfully signed in ... ")
        except Exception as e:
            print(e)
            return
    except smtplib.SMTPException as smerr:
    	print(smerr)
    	exit(0)
    except Exception as e:
    	print(e)
    	exit(0)

    for email in emails:
        if email == "":
            continue
        att = att.replace("{MAIL}", email) #replace {mail} in salutation in html if exists to email address

        # compile mail properties and attach message
        msg = MIMEMultipart()
        msg['From'] = login
        msg['To'] = email
        msg['Subject'] = subject
        if plain not in ("", " ", linesep, None):
            msg.attach(MIMEText(msg_body, 'plain', "utf-8")) #declare message syntax and encoding
        msg.attach(MIMEText(att, 'html', 'utf-8'))
        # send mail, else catch error
        try:
            s.send_message(msg)
            """Clear cached mail and signed mail, and prepare for next recipient"""
            del msg    
            count += 1 #count mails sent
            mol = f"{str(count)}   <|> {datetime.now()}   <|> mail successfully sent to {email}\n"
            log = open("mail_log.txt", "a+")
            log.write(mol)
            log.close()
            log = open("done_log.txt", "a+")
            log.write(f"{email}\n")
            log.close()
            print(mol)
        except Exception as e:
            log = open("errors.txt", "a+")
            log.write(f"\n[>{count}<] Error {e} while sending mail to {email}\n")
            log.close()
            print(f"\nError {e} while sending mail to {email}.")
    
        if count == 7500:
            sleep(86410)
            count = 0
        else:
            sleep(randint(28, 34))
    s.quit()


def get_args():
    parser = argparse.ArgumentParser(description='Mailer Parameters')
    parser.add_argument('-u', help='SMTP URL', required=True)
    parser.add_argument('-p', help='SMTP Port', required=True, type=int)
    parser.add_argument('-l', help='Login Email address', required=True)
    parser.add_argument('-pw', help='Login Password', required=True)
    parser.add_argument('-s', help='Email Subject', required=True)
    parser.add_argument('-pm', help='PlainText Message', required=False)
    parser.add_argument('-b', help='Html Email File', required=True)
    parser.add_argument('-f', help='Recipient File', required=True)
    return parser.parse_args()


def main():
    emls = []
    a = get_args()
    host = a.u
    port = a.p
    login = a.l
    password = a.pw
    subject = a.s

    msd_html = open(a.b, "r")
    html = msd_html.read()
    msd_html.close()
    del msd_html
    
    eml = open(a.f, "r")
    emails = eml.readlines()
    eml.close()
    del eml
    for em in emails:
        em = em.strip()
        if em in ("", " ", linesep, None):
            continue
        emls.append(em)
    del emails
    emails = emls
    del emls
    if a.pm not in ("", " ", linesep, None):
        plm = open(a.pm, "r")
        plain = plm.read()
        plm.close()
        startsend(host, port, login, password, subject, html, emails, plain)
    else:
        startsend(host, port, login, password, subject, html, emails)

if __name__ == "__main__":
    main()
    exit(0)